package emu.lunarcore.data.config;

import lombok.Getter;

/**
 *  Original name: LevelNPCInfo
 */
@Getter
public class NpcInfo extends ObjectInfo {
    private int NPCID;
}
