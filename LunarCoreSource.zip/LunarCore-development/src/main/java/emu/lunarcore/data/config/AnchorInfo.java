package emu.lunarcore.data.config;

/**
 *  Original name: LevelAnchorInfo
 */
public class AnchorInfo extends ObjectInfo {

}
